#!/usr/bin/python3
#import unix function 
import os
from subprocess import call

#clear the screen
os.system('clear')
print("The process strats from *nix, please make sure you have seen the mannual.")

#choose the key words by user
pro= input("Please select a protein family: \n")
tax= input("Specific taxonomic group: \n")
print("Thank you for choosing: " + pro + " | " + tax)

#do search online (NCBI), download the sequences (fasta), then store them as output 
sefe="esearch -db protein -query \" "+ pro + "[Protein Name] AND " + tax + "[Organism]\"\
 | efetch -db protein -format fasta > allsequences.fasta" 
call(sefe, shell=True)

#the number of seaching results
number=call("grep -c \">\" allsequences.fasta", shell=True)
print("There are " + str(number) + "results.")

#check if it is number
while True:
    print("Enter the number of sequence you would like to choose: ")
    numini= input()
    if numini.isdecimal():
        break
print("Please enter a number")





#Create a database
call("makeblastdb -in allsequences.fasta -dbtype prot -title new -out blastdb -parse_seqids", shell=True)
print("The database has been successfully created.")

#blastp analysis, limit evalue smaller to gain more realiable data, outfmt6 is table, threads 4 makes script run quicker 
call("blastp -query allsequences.fasta -db blastdb -out output_blastp.txt -outfmt 6 -evalue 1e-6 -num_threads 4", shell=True)
print("Blastp finished")
print("This the output file like:")
os.system("head output_blastp.txt"
os.system("wc -l output_blastp.txt")


#sort based on the third coloum and pick the first 250 sequences as input for clustalering
os.system("sort -k 3,3 -nr output_blastp | head -250 > sorted_blastp")

#extract


#aligning and ploting
print("Aligning starts...")
call("clustalo -i sorted_seq.fasta --maxnumseq 250 -o output_clustalo", shell=True)
print("Aligning has been finished.")

print("Plotting starts...")
call("plotcon -sequences output_clustalo -winsize 4 -graph x11", shell=True)
print("Figure of conservation has been made.")
##seems did not saved here

#build PROSITE motif database
prositedat="/localdisk/software/EMBOSS-6.6.0/share/EMBOSS/data/PROSITE/prosite.dat"
call=("prosextract -prositedir $prositedat", shell=True)
call=("patmatmotifs -sequence  -outfile final_output", shell=True)




print("All have done, Thanks")
