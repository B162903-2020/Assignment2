#!/usr/bin/python3
#import unix function 
import os
from subprocess import call

#clear the screen
os.system('clear')
print("The process strats from *nix, please make sure you have seen the mannual.")

#choose the key words by user
pro= input("Please select a protein family: \n")
tax= input("Specific taxonomic group: \n")
print("Thank you for choosing: " + pro + " | " + tax)

#do search online (NCBI), download the sequences (fasta), then store them as output 
sefe="esearch -db protein -query \" "+ pro + "[Protein Name] AND " + tax + "[Organism]\"\
 | efetch -db protein -format fasta > allsequences.fasta" 
call(sefe, shell=True)

#the number of seaching results
number=call("grep -c \">\" allsequences.fasta", shell=True)
print("\nThere are " + str(number) + "results.")

#check if it is number
while True:
    print("Enter the number of sequence you would like to choose: ")
    numini= input()
    if numini.isdecimal():
        break
print("Please enter a number")

#there should be another loop, and catch the real number  sequences that use chose, write into a new file called seq2.fasta


#Create a database
call("makeblastdb -in seq2.fasta -dbtype prot -title new -out blastdb -parse_seqids", shell=True)
print("The database has been successfully created.")


#blastp analysis, limit evalue smaller to gain more realiable data, outfmt6 is table, threads 4 makes script run quicker 
call("blastp -query seq2.fasta -db blastdb -out output_blastp.txt -outfmt 6 -evalue 1e-6 -num_threads 4", shell=True)
print("Blastp finished")
print("This the output file like:")
os.system("head output_blastp.txt"
os.system("wc -l output_blastp.txt")


#sort based on the third coloum and pick the first 250 sequences as input for clustalering
os.system("sort -k 3,3 -nr output_blastp | head -250 > sorted_blastp")


#extract, find id, back to seq2.fasta, find first 250, write into a new file called seq250.fasta


#aligning and plotting
print("Aligning starts...")
call("clustalo -i seq250.fasta --maxnumseq 250 -o output_clustalo", shell=True)
print("Aligning has been finished.")

print("Plotting starts...")
call("plotcon -sequences output_clustalo -winsize 4 -graph x11", shell=True)
print("Figure of conservation has been made.")
#seems did not saved as output here


#build PROSITE motif database
prositedat="/localdisk/software/EMBOSS-6.6.0/share/EMBOSS/data/PROSITE/prosite.dat"
call=("prosextract -prositedir $prositedat", shell=True)
call=("patmatmotifs -sequence  -outfile final_output", shell=True)


#find their name by using python


#extra options




#End
print("All have done, Thanks, press ctrl+d to exit")
