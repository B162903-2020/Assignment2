#!/usr/bin/python3
#import unix function 
import os, sys
from subprocess import call

#weird name in order to avoid return error as current folder exists
os.mkdir("runningspace2")
os.chdir("runningspace2")
#clear the screen
os.system('clear')
print("The process strats from *nix, please make sure you have seen the mannual.")

#choose the key words by user
pro= input("Please select a protein family: \n")
tax= input("Specific taxonomic group: \n")
print("Thank you for choosing: " + pro + " | " + tax)

#do search online (NCBI), download the sequences (fasta), then store them as output 
sefe="esearch -db protein -query \" "+ pro + "[Protein Name] AND " + tax + "[Organism]\"\
 | efetch -db protein -format fasta > allsequences.fasta" 
call(sefe, shell=True)

#the number of seaching results
number=call("grep -c \">\" allsequences.fasta", shell=True)
print("There are " + str(number) + "results.")
